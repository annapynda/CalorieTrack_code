from distutils.core import setup
setup(name='uc',
      version='1.0',
      py_modules=['uc'],
      )